# PowerShell script to create an encrypted RDS MySQL instance and write DB credentials to Secrets Manager.
# Edit the variables below before running.

# Variables - EDIT THESE
$Region = 'us-east-1'
$VpcId = '<YOUR_VPC_ID>'
$PrivateSubnetIds = '<subnet-1>,<subnet-2>' # comma-separated
$SecurityGroupName = 'cloudretail-lambda-db-sg'
$DBIdentifier = 'cloudretail-db-1'
$DBInstanceClass = 'db.t3.micro'
$Engine = 'mysql'
$EngineVersion = '8.0.31'
$AllocatedStorage = 20
$MasterUsername = 'cloudadmin'
$MasterPassword = '<StrongPasswordHere>'
$DBName = 'cloudretail'
$KmsKeyId = '' # optional; leave blank to use default AWS managed key for RDS
$SecretName = 'cloudretail/dev/db'

Set-Location -Path (Split-Path -Parent $MyInvocation.MyCommand.Definition)

Write-Host "Region: $Region"

# Normalize human-friendly region aliases (accept inputs like 'us-east-1n-virginia')
if ($Region -match 'virginia' -or $Region -match 'n-virginia' -or $Region -match 'us-east-1n') {
  Write-Host "Normalizing region alias '$Region' to 'us-east-1'"
  $Region = 'us-east-1'
}

# Create security group
$sg = aws ec2 create-security-group --group-name $SecurityGroupName --description "Security group for lambdas to reach RDS" --vpc-id $VpcId --region $Region | ConvertFrom-Json
$sgId = $sg.GroupId
Write-Host "Created SG: $sgId"

# Allow inbound MySQL from same SG (used by Lambdas attached to the SG)
aws ec2 authorize-security-group-ingress --group-id $sgId --protocol tcp --port 3306 --cidr 10.0.0.0/8 --region $Region
Write-Host "Opened port 3306 (adjust CIDR as required)."

# Create DB subnet group
$subnetIds = $PrivateSubnetIds -split ',' | ForEach-Object { $_.Trim() }
$subnetJson = @{DBSubnetGroupName = "$DBIdentifier-subnet-group"; SubnetIds = $subnetIds; DBSubnetGroupDescription = "Subnet group for $DBIdentifier"} | ConvertTo-Json -Depth 5
aws rds create-db-subnet-group --cli-input-json $subnetJson --region $Region
Write-Host "Created DB subnet group."

# Create RDS instance
$createArgs = @(
  "--db-instance-identifier", $DBIdentifier,
  "--db-instance-class", $DBInstanceClass,
  "--engine", $Engine,
  "--engine-version", $EngineVersion,
  "--allocated-storage", $AllocatedStorage.ToString(),
  "--master-username", $MasterUsername,
  "--master-user-password", $MasterPassword,
  "--db-name", $DBName,
  "--vpc-security-group-ids", $sgId,
  "--db-subnet-group-name", "$DBIdentifier-subnet-group",
  "--storage-encrypted"
)
if ($KmsKeyId) { $createArgs += @("--kms-key-id", $KmsKeyId) }

Write-Host "Creating RDS instance (this can take several minutes)..."
aws rds create-db-instance $createArgs --region $Region | Out-Null

Write-Host "Waiting for DB instance to become available..."
aws rds wait db-instance-available --db-instance-identifier $DBIdentifier --region $Region

$endpoint = aws rds describe-db-instances --db-instance-identifier $DBIdentifier --region $Region --query "DBInstances[0].Endpoint.Address" --output text
Write-Host "RDS endpoint: $endpoint"

# Store credentials in Secrets Manager
$secretPayload = @{
  host = $endpoint
  username = $MasterUsername
  password = $MasterPassword
  dbname = $DBName
} | ConvertTo-Json

# If secret exists, update; otherwise create
$exists = (aws secretsmanager list-secrets --region $Region --query "SecretList[?Name=='$SecretName'] | length(@)")
if ($exists -gt 0) {
  aws secretsmanager put-secret-value --secret-id $SecretName --secret-string $secretPayload --region $Region
  Write-Host "Updated existing secret: $SecretName"
} else {
  aws secretsmanager create-secret --name $SecretName --description "DB credentials for cloudretail" --secret-string $secretPayload --region $Region | Out-Null
  Write-Host "Created secret: $SecretName"
}

Write-Host "Done. Remember to set SECRET_ARN in infra/serverless/.env to the secret ARN (use 'aws secretsmanager describe-secret')."
